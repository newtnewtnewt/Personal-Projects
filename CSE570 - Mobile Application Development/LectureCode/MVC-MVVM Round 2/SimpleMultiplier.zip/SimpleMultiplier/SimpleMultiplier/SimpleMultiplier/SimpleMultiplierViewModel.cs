using System;
using System.ComponentModel;

namespace SimpleMultiplier
{
    class SimpleMultiplierViewModel : INotifyPropertyChanged
    {
        double multiplicand, multiplier, product, addend, adder, sum, stepAdder, stepAddend, stepSum;

        public event PropertyChangedEventHandler PropertyChanged;

        public double Multiplicand
        {
            set
            {
                if (multiplicand != value)
                {
                    multiplicand = value;
                    OnPropertyChanged("Multiplicand");
                    UpdateProduct();
                }
            }
            get
            {
                return multiplicand;
            }
        }

        public double Multiplier
        {
            set
            {
                if (multiplier != value)
                {
                    multiplier = value;
                    OnPropertyChanged("Multiplier");
                    UpdateProduct();
                }
            }
            get
            {
                return multiplier;
            }
        }

        public double Product
        {
            protected set
            {
                if (product != value)
                {
                    product = value;
                    OnPropertyChanged("Product");
                }
            }
            get
            {
                return product;
            }
        }

        void UpdateProduct()
        {
            Product = Multiplicand * Multiplier;
        }

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public double Addend
        {
            set
            {
                if (addend != value)
                {
                    addend = value;
                    OnPropertyChanged("Addend");
                    UpdateSum();
                }
            }
            get
            {
                return addend;
            }
        }

        public double Adder
        {
            set
            {
                if (adder != value)
                {
                    adder = value;
                    OnPropertyChanged("Adder");
                    UpdateSum();
                }
            }
            get
            {
                return adder;
            }
        }

        public double Sum
        {
            protected set
            {
                if (sum != value)
                {
                    sum = value;
                    OnPropertyChanged("Sum");
                }
            }
            get
            {
                return sum;
            }
        }

        public double StepAddend
        {
            set
            {
                if (stepAddend != value)
                {
                    stepAddend = value;
                    OnPropertyChanged("StepAddend");
                    UpdateStepSum();
                }
            }
            get
            {
                return stepAddend;
            }
        }

        public double StepAdder
        {
            set
            {
                if (stepAdder != value)
                {
                    stepAdder = value;
                    OnPropertyChanged("StepAdder");
                    UpdateStepSum();
                }
            }
            get
            {
                return stepAdder;
            }
        }

        public double StepSum
        {
            protected set
            {
                if (stepSum != value)
                {
                    stepSum = value;
                    OnPropertyChanged("StepSum");
                }
            }
            get
            {
                return stepSum;
            }
        }

        void UpdateStepSum()
        {
            StepSum = StepAdder + StepAddend;
        }

        void UpdateSum()
        {
            Sum = Adder + Addend;
        }
    }
}
