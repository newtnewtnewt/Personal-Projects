﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace Numpad
{
    class MainPage : ContentPage
    {
        Label text = new Label
        {
            Text = "",
            FontSize = 50,
            FontAttributes = FontAttributes.Bold,
            HorizontalOptions = LayoutOptions.Center
        };
        public MainPage()
        {
            Button[] buttonArray = new Button[10];
            for(int i = 0; i < 10; i++)
            {
                buttonArray[i] = new Button { Text = "" + i };
                buttonArray[i].Clicked += OnClicked;
            }
            Grid grid = new Grid
            {
                VerticalOptions = LayoutOptions.FillAndExpand,
                Margin = new Thickness(10),
                RowDefinitions =
                {
                        new RowDefinition { Height = GridLength.Auto },
                        new RowDefinition { Height = GridLength.Auto },
                        new RowDefinition { Height = new GridLength(1, GridUnitType.Star) },
                        new RowDefinition { Height = new GridLength(100, GridUnitType.Absolute) }
                 },
                ColumnDefinitions =
                {
                        new ColumnDefinition { Width = GridLength.Auto },
                        new ColumnDefinition { Width = new GridLength (1, GridUnitType.Star) },
                        new ColumnDefinition { Width = new GridLength (100, GridUnitType.Absolute) }
                }
            };

            grid.Children.Add(text, 0, 3, 0, 1) ;
            for(int i = 0; i < 10; i++)
            {
                grid.Children.Add(buttonArray[i], i % 3, (int)(i / 3) + 1);
            }
            this.Content = grid;
        }

        private void OnClicked(object sender, EventArgs e)
        {
            Button sent = (Button)sender;
            if(sent.Text == "1")
            {
                text.Text = text.Text + "1";
            }
            if (sent.Text == "2")
            {
                text.Text = text.Text + "2";
            }
            if (sent.Text == "3")
            {
                text.Text = text.Text + "3";
            }
            if (sent.Text == "4")
            {
                text.Text = text.Text + "4";
            }
            if (sent.Text == "5")
            {
                text.Text = text.Text + "5";
            }
            if (sent.Text == "6")
            {
                text.Text = text.Text + "6";
            }
            if (sent.Text == "7")
            {
                text.Text = text.Text + "7";
            }
            if (sent.Text == "8")
            {
                text.Text = text.Text + "8";
            }
            if (sent.Text == "9")
            {
                text.Text = text.Text + "9";
            }
            if (sent.Text == "0")
            {
                text.Text = text.Text + "0";
            }
        }
    }
}
