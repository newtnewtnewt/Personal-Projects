﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace LockedContacts
{
    // Learn more about making custom code visible in the Xamarin.Forms previewer
    // by visiting https://aka.ms/xamarinforms-previewer
    [DesignTimeVisible(false)]
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
            switchName.IsToggled = Preferences.Get("switchState", false);
        }
        public static string GetFullFileName(string baseName)
        {
            string libFolder = FileSystem.AppDataDirectory;
            string fname = System.IO.Path.Combine(libFolder, baseName);
            return fname;
        }
        private void Button_Clicked(object sender, EventArgs e)
        {
            Button sentButton = (Button)sender;
            if (sentButton.Text == "Add" && !Preferences.Get("switchState", false))
            {
                nameList.Text = nameList.Text + entryName.Text + "\n";
            }
            else
            {
                string fname = GetFullFileName("contacts.txt");
                StreamWriter sw = new StreamWriter(fname);
                sw.Write(nameList.Text);
                sw.Close();
            }
        }

        private void Switch_Toggled(object sender, ToggledEventArgs e)
        {
            Xamarin.Forms.Switch sw = (Xamarin.Forms.Switch)sender;
            Preferences.Set("switchState", sw.IsToggled);
        }
        
        
    }
}
