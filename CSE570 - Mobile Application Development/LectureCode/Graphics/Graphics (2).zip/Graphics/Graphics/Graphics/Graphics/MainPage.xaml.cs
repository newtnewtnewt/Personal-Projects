﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using SkiaSharp;
using SkiaSharp.Views.Forms;
using System.Diagnostics;

namespace Graphics {
	// Learn more about making custom code visible in the Xamarin.Forms previewer
	// by visiting https://aka.ms/xamarinforms-previewer
	[DesignTimeVisible(false)]
	public partial class MainPage : ContentPage {
		Stopwatch stopwatch = new Stopwatch();
		bool pageIsActive;
		Color color = Color.Red;
        float bar1Height = 1.0f;
        float bar2Height = 1.0f;
		public MainPage() {
			InitializeComponent();
		}
		protected async override void OnAppearing() {
			base.OnAppearing();
			pageIsActive = true;
			await AnimationLoop();
		}
		protected override void OnDisappearing() {
			base.OnDisappearing();
			pageIsActive = false;
		}
		void OnCanvas1ViewPaintSurface(object sender, SKPaintSurfaceEventArgs args) {
			SKImageInfo info = args.Info;
			SKSurface surface = args.Surface;
			SKCanvas canvas = surface.Canvas;

			canvas.Clear();
			SKPaint paint = new SKPaint {
				Style = SKPaintStyle.Stroke,
				Color = color.ToSKColor(),
				StrokeWidth = 1
			};
			float r = Math.Min(info.Width, info.Height) / 2.0f;
			canvas.DrawCircle(info.Width / 2, info.Height / 2, r, paint);
			canvas.DrawCircle(info.Width / 2, info.Height / 2, r/2, paint);
		}
		async Task AnimationLoop() {
			stopwatch.Start();
			while (pageIsActive) {
				double t = stopwatch.Elapsed.TotalSeconds % 2;
				if (t < 1)
					color = Color.Red;
				else
					color = Color.Blue;
				view1.InvalidateSurface();
				await Task.Delay(TimeSpan.FromSeconds(1.0 / 30));
			}
			stopwatch.Stop();
		}
		void OnCanvas2ViewPaintSurface(object sender, SKPaintSurfaceEventArgs args) {
			SKImageInfo info = args.Info;
			SKSurface surface = args.Surface;
			SKCanvas canvas = surface.Canvas;
			canvas.Clear();
			SKPaint paint = new SKPaint {
				Style = SKPaintStyle.Stroke,
				Color = color.ToSKColor(),
				StrokeWidth = 1,
				TextSize = 20,
				
			};

			float r = Math.Min(info.Width, info.Height) / 2.0f;
			canvas.DrawCircle(info.Width / 2, info.Height / 2, r, paint);
			canvas.DrawText("Hello world", 10, 10, paint);

		}
		private void OnView2Tapped(object sender, EventArgs e) {
			TappedEventArgs args = (TappedEventArgs)e;
			view2.InvalidateSurface();
		}

        void OnCanvas3ViewPaintSurface(object sender, SKPaintSurfaceEventArgs args)
        {
            SKImageInfo info = args.Info;
            SKSurface surface = args.Surface;
            SKCanvas canvas = surface.Canvas;
            canvas.Clear();
            SKPaint paint = new SKPaint
            {
                Style = SKPaintStyle.Stroke,
                Color = color.ToSKColor(),
                StrokeWidth = 1,
                TextSize = 20,

            };

            float r = Math.Min(info.Width, info.Height) / 2.0f;
            canvas.DrawRect(100, 100, 50, bar1Height, paint);        
            canvas.DrawRect(110, 100, 50, bar2Height, paint);

        }

        private void Bar1_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Bar2_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
