﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Http;
using System.Threading.Tasks;
using System.Diagnostics;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace RestConsole {
	class RestExample {
		// You will need to get your own keys:
		// https://home.openweathermap.org/users/sign_up
		// https://timezonedb.com/register

		public static string OpenWeatherMapEndpoint = "https://api.openweathermap.org/data/2.5/weather";
		public static string OpenWeatherMapAPIKey = "4b458973fac9a990ffc580b76ddb410e";

		public static string TimeZoneEndpoint = "http://api.timezonedb.com/v2.1/get-time-zone";
		public static string TimeZoneAPIKey = "I8LUFUFCNJGC";

		public HttpClient client = new HttpClient();
		public async Task<string> GetResponse(string query) {
			string data = null;
			try {
				var response = await client.GetAsync(query);
				if (response.IsSuccessStatusCode) {
					data = await response.Content.ReadAsStringAsync();
				}
			}
			catch (Exception ex) {
				Debug.WriteLine("\t\tERROR {0}", ex.Message);
			}
			return data;
		}
		public string CreateWeatherQuery(string cityName) {
			string requestUri = OpenWeatherMapEndpoint;
			requestUri += $"?q={cityName}";
			requestUri += "&units=imperial"; // or units=metric
			requestUri += $"&APPID={OpenWeatherMapAPIKey}";
			return requestUri;
		}
		public async Task<string> GetWeatherQueryResult() {
			Console.Write("Please enter a big US city: ");
			string city = Console.ReadLine().Trim();
			string query = CreateWeatherQuery(city);
			string result = null;

			try {
				var response = await client.GetAsync(query);
				if (response.IsSuccessStatusCode) {
					result = await response.Content.ReadAsStringAsync();
				}
			}
			catch (Exception ex) {
				Debug.WriteLine("\t\tERROR {0}", ex.Message);
				Environment.Exit(0);
			}

			return result;
		}
		public void ProcessWeatherQuery() {
			string response = GetWeatherQueryResult().Result;
			WeatherData weatherData = JsonConvert.DeserializeObject<WeatherData>(response);
			Console.WriteLine("Using WeatherData class");
			Console.WriteLine(weatherData.Title);
			Console.WriteLine(weatherData.Visibility);
			Console.WriteLine(weatherData.Main.Temperature);
			Console.WriteLine(weatherData.Wind.Speed);

			var smallDef = new { title = "", visibility = 0 };
			var smallObj = JsonConvert.DeserializeAnonymousType(response, smallDef);
			Console.WriteLine("Using small anonymous class");
			Console.WriteLine(smallObj.title + " " + smallObj.visibility);

			dynamic d = JObject.Parse(response);
			Console.WriteLine("Using dynamic class");
			Console.WriteLine(d.name);
			Console.WriteLine(d.visibility);
			Console.WriteLine(d.main.temp);
			Console.WriteLine(d.wind.speed);
		}
        public string CreateTimeQuery(string timeZone)
        {
            string requestUri = TimeZoneEndpoint;
            requestUri += $"?key={TimeZoneAPIKey}";
            requestUri += "&by=zone"; // or units=metric
            requestUri += "&format=json";
            requestUri += $"&zone={timeZone}";
            return requestUri;
        }
        public async Task<string> GetTimeZoneData()
        {
            Console.WriteLine("Please type in a Time Zone: ");
            string timeZone = Console.ReadLine().Trim();
            string query = CreateTimeQuery(timeZone);
            string result = null;

            try
            {
                var response = await client.GetAsync(query);
                if (response.IsSuccessStatusCode)
                {
                    result = await response.Content.ReadAsStringAsync();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("\t\tERROR {0}", ex.Message);
                Environment.Exit(0);
            }

            return result;
        }


        public void ProcessTimeZone()
        {
            string jsonResponse = GetTimeZoneData().Result;
            TimeData timeData = JsonConvert.DeserializeObject<TimeData>(jsonResponse);
            Console.WriteLine("Using TimeData class");
            Console.WriteLine(timeData.Message);
            Console.WriteLine(timeData.Zone);
            Console.WriteLine(timeData.Time);
            // This line will not break: Console.WriteLine(timeData.Wrong);

            dynamic d = JObject.Parse(jsonResponse);
            Console.WriteLine("Using dynamic class");
            Console.WriteLine(d.message);
            Console.WriteLine(d.zoneName);
            Console.WriteLine(d.formatted);
            // This line will break: Console.WriteLine(d.fakeParam);
        }
        public static void Main(string[] args)
        {
            RestExample rest = new RestExample();
            BookAPI books = new BookAPI();
            rest.ProcessWeatherQuery();
            rest.ProcessTimeZone();
            books.OtherRun();
           
        }
    }
}
