﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Http;
using System.Threading.Tasks;
using System.Diagnostics;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;


namespace RestConsole
{
    class BookAPI
    {
        public string BookAPIEndpoint = "https://api.itbook.store/1.0/books/";

        public HttpClient client = new HttpClient();
        public async Task<string> GetWeatherQueryResult()
        {
            Console.Write("Please enter an ISBN for a CS Book: ");
            string isbn = Console.ReadLine().Trim();
            string query = CreateBookQuery(isbn);
            string result = null;

            try
            {
                var response = await client.GetAsync(query);
                if (response.IsSuccessStatusCode)
                {
                    result = await response.Content.ReadAsStringAsync();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("\t\tERROR {0}", ex.Message);
                Environment.Exit(0);
            }

            return result;
        }
        public string CreateBookQuery(string isbn)
        {
            string requestUri = BookAPIEndpoint;
            requestUri += $"/{isbn}";
            return requestUri;
        }
        public void OtherRun()
        {
            BookAPI bookReq = new BookAPI();
            string jsonObj = bookReq.GetWeatherQueryResult().Result;
            dynamic d = JObject.Parse(jsonObj);
            Console.WriteLine("Using dynamic class");
            Console.WriteLine(d.isbn13);
            Console.WriteLine(d.title);
            Console.WriteLine(d.subtitle);
            Console.WriteLine(d.authors);
            Console.WriteLine(d.pages);
            Console.WriteLine(d.year);
            Console.WriteLine(d.price);
            Console.WriteLine(d.rating);
        }

    }
}
