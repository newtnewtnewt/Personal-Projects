﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace DBTraining {
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class QueriesPage : ContentPage {
        public QueriesPage() {
            InitializeComponent();
        }
        private void OnClicked(object sender, EventArgs e) {
            TimeSpan hour = new TimeSpan(1, 0, 0);
            if (sender == HrRunAll)
            {
                lv.ItemsSource = from activity in DB.conn.Table<Activity>()
                                 where activity.Sport.Equals("Running") && activity.Duration >= hour
                                 select activity;
            }
            else if(sender == HrRunDates)
            {
                lv.ItemsSource = from activity in DB.conn.Table<Activity>()
                                 where activity.Sport.Equals("Running") && activity.Duration >= hour
                                 select activity.DatePerformed.Date.ToString("MM/dd/yyyy") ;
            }
            else if(sender == HrRunDateDuration)
            {
                lv.ItemsSource = from activity in DB.conn.Table<Activity>()
                                 where activity.Sport.Equals("Running") && activity.Duration >= hour
                                 select activity.DatePerformed.Date.ToString("MM/dd/yyyy") + " " + activity.Duration;

            }
            else if(sender == LRunAll)
            {
                var x = from activity in DB.conn.Table<LongActivityDefinition>()
                        where activity.Sport.Equals("Running")
                        select activity.Duration;
                Display(x);
                TimeSpan cap = x.ToList()[0];

                lv.ItemsSource = from otheractivity in DB.conn.Table<Activity>()
                                 where otheractivity.Sport.Equals("Running") && otheractivity.Duration >= cap
                                 select otheractivity;
            }
            else if(sender == Calories)
            {
                var activityList = from otheractivity in DB.conn.Table<Activity>() 
                                 select otheractivity ;
                List<Activity> activitiesTotal = activityList.ToList();
                lv.ItemsSource = from a in activitiesTotal
                                 where a.Calories >= 500
                                 select a;
            }
        }
        public DateTime DatePerformed { get; set; }
        public TimeSpan Duration { get; set; }
        public string Sport { get; set; }
        
        
        public int Cals
        {
            get
            {
                int totalMinutes = (int)Math.Round(Duration.TotalMinutes);
                switch (Sport)
                {  // These are not accurate
                    case "Swimming": return totalMinutes * 10;
                    case "Biking": return totalMinutes * 10;
                    case "Running": return totalMinutes * 12;
                    case "Walking": return totalMinutes * 5;
                    case "Yoga": return totalMinutes * 7;
                    case "Strength Training": return totalMinutes * 10;
                    default: return totalMinutes * 10;
                }
            }
        }
        public static void Display<T> (IEnumerable<T> items)
        {
            Debug.Write("[");
            foreach (T item in items)
            {
                Debug.WriteLine(item.ToString() + " ");
            }
            Debug.WriteLine("]");

        }
    }
}
