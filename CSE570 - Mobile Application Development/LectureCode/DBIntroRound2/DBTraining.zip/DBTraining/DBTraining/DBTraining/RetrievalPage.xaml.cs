﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace DBTraining {
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class RetrievalPage : ContentPage {
        public RetrievalPage() {
            InitializeComponent();
        }
        protected override void OnAppearing() {
            base.OnAppearing();
            lvActivities1.ItemsSource = null;
            lvActivities2.ItemsSource = null;
        }
        private void SportSelected(object sender, EventArgs e) {
            string S = (string)sport.SelectedItem;
            lvActivities1.ItemsSource = DB.conn.Table<Activity>().Where(a => a.Sport.Equals(S));
            lvActivities2.ItemsSource = DB.conn.Table<Activity>().Where(a => a.Sport.Equals(S));
        }
    }
}