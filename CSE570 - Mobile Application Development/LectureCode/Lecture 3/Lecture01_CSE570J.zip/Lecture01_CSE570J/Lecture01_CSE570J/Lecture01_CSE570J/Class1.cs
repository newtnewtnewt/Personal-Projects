﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace Lecture01_CSE570J
{
    class MainPage : ContentPage
    {
        Entry name;
        Label label;
        Button update;
        public MainPage()
        {
            name = new Entry { Text = "Enter some stuff" };
            label = new Label() { Text = "This is where your text will appear" };
            update = new Button() { };
            update.Text = "button text";
            update.Clicked += OnClick;
            update.TextColor = Color.Green;
            update.BackgroundColor = Color.Blue;

            StackLayout panel = new StackLayout();
            panel.Children.Add(name);
            panel.Children.Add(label);
            panel.Children.Add(update);
            

            this.Content = panel;
        }
        private void OnClick(object sender, EventArgs e)
        {
            label.Text = name.Text;
        }
    }

}
