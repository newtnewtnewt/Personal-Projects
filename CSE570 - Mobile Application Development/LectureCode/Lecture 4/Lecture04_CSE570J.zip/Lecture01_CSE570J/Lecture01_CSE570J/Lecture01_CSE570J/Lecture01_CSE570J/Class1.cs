﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using Xamarin.Forms;

namespace Lecture01_CSE570J
{
    class MainPage : ContentPage
    {
        Entry entry;
        Label entryLabel;
        Label buttonLabel;
        Label checkBoxLabel;
        Label switchLabel;
        Label sliderLabel;
        Label stepperLabel;
        public MainPage()
        {
            entry = new Entry { Text = "" };
            entry.TextChanged += OnChanged;
            entryLabel = new Label { Text = "0" };
            StackLayout panel = new StackLayout();
            StackLayout entryLayout = new StackLayout { Orientation = StackOrientation.Horizontal };
            StackLayout buttonLayout = new StackLayout { Orientation = StackOrientation.Horizontal };
            StackLayout checkBoxLayout = new StackLayout { Orientation = StackOrientation.Horizontal };
            StackLayout switchLayout = new StackLayout { Orientation = StackOrientation.Horizontal };
            StackLayout sliderLayout = new StackLayout { Orientation = StackOrientation.Horizontal };
            StackLayout stepperLayout = new StackLayout { Orientation = StackOrientation.Horizontal };

            Button clickMe = new Button { Text = "Click Me" };
            clickMe.Clicked += OnClick;
            buttonLabel = new Label { Text = "0" };

            CheckBox checkBox = new CheckBox { IsChecked = false };
            checkBoxLabel = new Label { Text = "false" };
            checkBox.CheckedChanged += OnCheckBoxCheckedChanged;

            Switch sw = new Switch { IsToggled = false };
            switchLabel = new Label { Text = "false" };
            sw.Toggled += OnToggled;

            Slider slide = new Slider { WidthRequest = 100};
            sliderLabel = new Label { Text = "0.000" };
            slide.ValueChanged += OnSliderValueChanged;






            entryLayout.Children.Add(entry);
            entryLayout.Children.Add(entryLabel);

            buttonLayout.Children.Add(clickMe);
            buttonLayout.Children.Add(buttonLabel);

            checkBoxLayout.Children.Add(checkBox);
            checkBoxLayout.Children.Add(checkBoxLabel);

            switchLayout.Children.Add(sw);
            switchLayout.Children.Add(switchLabel);

            sliderLayout.Children.Add(slide);
            sliderLayout.Children.Add(sliderLabel);
            

            panel.Children.Add(entryLayout);
            panel.Children.Add(buttonLayout);
            panel.Children.Add(checkBoxLayout);
            panel.Children.Add(switchLayout);
            panel.Children.Add(sliderLayout);
            

            this.Content = panel;

        }

        private void OnSliderValueChanged(object sender, ValueChangedEventArgs args)
        {
            sliderLabel.Text = "" + args.NewValue; 
        }

        private void OnToggled(object sender, ToggledEventArgs e)
        {
            switchLabel.Text = (!Boolean.Parse(switchLabel.Text)) + "";
        }

        private void OnCheckBoxCheckedChanged(object sender, CheckedChangedEventArgs e)
        {
            checkBoxLabel.Text = (!Boolean.Parse(checkBoxLabel.Text)) + "";
        }

        private void OnChanged(object sender, TextChangedEventArgs e)
        {
            entryLabel.Text = entry.Text.Length.ToString();
        }
        private void OnClick(object sender, EventArgs e)
        {
            buttonLabel.Text = (Int32.Parse(buttonLabel.Text) + 1).ToString();
        }
    }

}