﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace XAMLExtendedTestRun
{
    public static class SharedResources
    {
        public static Color ButtonFGColor
        {
            get{ return Color.Red; }
        }
        public static Color ButtonBGColor
        {
            get { return Color.Yellow;  }

        }
    }
}
