﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TabbedPages_CSharp
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
            TabbedPage tabbedPage = new TabbedPage();
            tabbedPage.Children.Add(new AlarmPage());
            tabbedPage.Children.Add(new EventPage());
            tabbedPage.Children.Add(new TimerPage());
            tabbedPage.Children.Add(new AboutPage());
            tabbedPage.Children[0].Title = "Alarm";
            tabbedPage.Children[1].Title = "Event";
            tabbedPage.Children[2].Title = "Timer";
            tabbedPage.Children[3].Title = "About";
            tabbedPage.SelectedTabColor = Color.Red;
            tabbedPage.UnselectedTabColor = Color.Black;
            MainPage = tabbedPage;
        }

        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }
    }
}
