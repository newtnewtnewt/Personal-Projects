﻿using System;
using System.Collections.Generic;
using System.Text;
using SQLite;


namespace DBIntro {
    [Table("person")]
    public class Person
    {
        // PrimaryKey is typically numeric 
        [PrimaryKey, AutoIncrement, Column("_id")]
        public int Id { get; set; }

        [MaxLength(250), Unique]
        public string Username { get; set; }

        [MaxLength(10), Column("_gender")]

        public string Gender { get; set; }

        [MaxLength(20), Column("_date")]

        public DateTime Date { get; set; }

        [MaxLength(20), Column("_ssn")]
        public string SSN { get; set; }


        public override string ToString()
        {
            return string.Format("{0} {1} {2} {3} {4}", Id, Username, Gender, Date, SSN);
        }

    }
}
