﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using SQLite;
using Xamarin.Essentials;

namespace DBIntro
{
    // Learn more about making custom code visible in the Xamarin.Forms previewer
    // by visiting https://aka.ms/xamarinforms-previewer
    [DesignTimeVisible(false)]
    public partial class MainPage : ContentPage
    {
        SQLiteConnection conn;
        public MainPage()
        {
            InitializeComponent();
            string libFolder = FileSystem.AppDataDirectory;
            string fname = System.IO.Path.Combine(libFolder, "Personnel.db");
            conn = new SQLiteConnection(fname);
            conn.CreateTable<User>();
            conn.CreateTable<Person>();
        }

        private void Button_Clicked(object sender, EventArgs e)
        {
            User newUser = new User { Username = name.Text };
            conn.Insert(newUser);
            List<User> allUsers = conn.Table<User>().ToList();
        }

        private void AddPersonButton_Clicked(object sender, EventArgs e)
        {
            Person newPerson = new Person { Username = otherName.Text, Date = birthDate.Date, Gender = (Gender.IsToggled ? "male" : "female"), SSN = SSN.Text };
            conn.Insert(newPerson);
            List<Person> allUsers = conn.Table<Person>().ToList();
            displayPersons.ItemsSource = allUsers;
        }
    }
}
