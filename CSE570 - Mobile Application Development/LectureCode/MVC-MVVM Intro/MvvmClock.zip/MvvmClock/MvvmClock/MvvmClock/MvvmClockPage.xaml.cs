using System;
using Xamarin.Forms;

namespace MvvmClock
{
    public partial class MvvmClockPage : ContentPage
    {
        public MvvmClockPage()
        {
            InitializeComponent();
        }
    }
}
