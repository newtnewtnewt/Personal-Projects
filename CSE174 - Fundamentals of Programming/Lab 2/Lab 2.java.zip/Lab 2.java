public class Whatever{
  
  public static void main(String args[]){
    
    import Scanner sc = new Scanner(System.in); 
    int radius = sc.nextInt();
    int radius2 = sc.nextInt();
    
    
   
    
  }
}