/* Name: Noah Dunn
 * Class: CSE 174 Section I
 * Instructor: Dr. Alberto-Castro Hernandez 
 * Date: 9/5/2017
 * Description: Display a Cartoon figure with a speech bubble
 * */


public class Cartoon{
   
   public static void main(String args[]) {
      
      System.out.println("  /\\_/\\   /--------------\\")   ;   //Row 1 of Cartoon
      System.out.println(" (*  * )---<    Eat     >      ");    //Row 2 of Cartoon
      System.out.println("\\(  #  )/  \\  Veggies /");          //Row 3 of Cartoon
      System.out.println(" |     |     \\________/");           //Row 4 of Cartoon
      System.out.println(" \\_/\\_/");                          //Row 5 of Cartoon
                            
   } //end main method 
}  //end class Cartoon
      