/* Name: Noah Dunn
 * Class: CSE 174 Section I
 * Instructor: Dr. Alberto-Castro Hernandez 
 * Date: 9/5/2017
 * Description: Print a Christmas tree!
 * */


public class ChristmasTree{
   
   public static void main(String args[]) {
      
      System.out.println("    /\\\'");       //Drawing Line 1 
      System.out.println("   /  \\\'");      //Drawing Line 2 
      System.out.println("  /    \\\'");     //Drawing Line 3 
      System.out.println(" /      \\\'");    //Drawing Line 4 
      System.out.println(" --------");       //Drawing Line 5 
      System.out.println("   \"  \"");       //Drawing Line 6 
      System.out.println("   \"  \"");       //Drawing Line 7 
      System.out.println("   \"  \"");       //Drawing Line 8                 
   } //end main method
}  // end class ChristmasTree
                            
                            